﻿# Поддержавшие проект

заполняется по данным https://salt.bountysource.com/teams/silverbulleters

как попасть в этот список, читайте [тут](./DONATIONS.md)

## Список поддержавших

> он ждет только Вас !!!

Большая благодарность:

* https://github.com/rozhkovdmitriy
* https://github.com/Hissin
